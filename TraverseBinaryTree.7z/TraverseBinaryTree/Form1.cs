﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TraverseBinaryTree
{
    public partial class Form1 : Form
    {
        public int digit { get; set; }
      //  public Tree theTree { get; set; }
       public  Tree theTree = new Tree();
        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show(this.Input.Text);
            digit = int.Parse(this.Input.Text);
            theTree.Insert(digit);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            theTree.Preorder(theTree.ReturnRoot());
        }
    }
}
