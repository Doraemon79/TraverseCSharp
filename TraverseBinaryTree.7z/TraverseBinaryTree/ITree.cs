﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraverseBinaryTree
{
    public interface ITree
    {

        Node ReturnRoot();
        void Insert(int id);
        void Preorder(Node Root);
        void Inorder(Node Root);
        void Postorder(Node Root);

    }
}
