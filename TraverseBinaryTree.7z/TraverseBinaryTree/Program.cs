﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TraverseBinaryTree
{
    static class Program
    {
       


        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
          //  Tree theTree = new Tree();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());





   //         Console.WriteLine("Inorder traversal resulting Tree Sort");
   //    //     theTree.Inorder(theTree.ReturnRoot());
   //         Console.WriteLine(" ");

   //         Console.WriteLine();
   //         Console.WriteLine("Preorder traversal");
   //  //       theTree.Preorder(theTree.ReturnRoot());
   //         Console.WriteLine(" ");

   //         Console.WriteLine();
   //         Console.WriteLine("Postorder traversal");
   ////         theTree.Postorder(theTree.ReturnRoot());
   //         Console.WriteLine(" ");

   //         Console.ReadLine();
        }


    }
}
